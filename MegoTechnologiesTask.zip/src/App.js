import React from "react";
import { Provider } from "react-redux";
import { configStore } from "./state/store";
import { Course } from "./components/course";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import CourseDetails from "./components/courseDetails";
function App() {
  const localstore = configStore();
  return (
    <div className="main">
      <h1 style={{background:'purple',color:'white',textAlign:'center',padding:'1rem',textShadow:'1px 2px 1px black',letterSpacing:'2px' }}>XYZ Online Learning Courses</h1>
      <Provider store={localstore}>
        <BrowserRouter>
          {/* <Course /> */}
          <Routes>
            <Route path="/coursedetails" element={<CourseDetails />} />
            <Route path="/" element={<Course />} />
          </Routes>
        </BrowserRouter>
      </Provider>
    </div>
  );
}

export default App;
