import styled from "styled-components";



export const MainContainer   =styled.div`
/* border:2px solid red; */
grid-template-columns:30% 69%;
/* background-color:pink; */
column-gap:6px;
display:grid;
height:26rem;

`
export const ImageContainer  =styled.div`
position: relative;
left:0;
top:0;
background-color:lightgrey;
 padding:2%;
 border-radius:12px;
`
export const  Img =styled.img`
width:100%;
height:100%;
border-radius:12px;
box-shadow:1px 2px 2px 1px grey;
`
export const  CourseDetailsContainer =styled.div`
background-color:lightgrey;
border-radius:12px;

`
export const Coursetitle=styled.div`
background-color:grey;
 box-shadow:1px 2px 2px 1px black; 
 width:100%;
`

export const TitleHeading  =styled.h2`
margin-left:3%;
text-align:center;
font-size:2rem;
width:100%;
color:#fff;

text-shadow:2px 2px 2px black;
`
export const  CourseInfo =styled.p`

margin-left:3%;
text-align:left;
font-size:1.1rem;
justify-content:center;
text-align:center;

`
export const  CourseName =styled.p`
margin-left:3%;
text-align:left;
font-size:1.1rem;
`
export const   CourseCategory=styled.p`
margin-left:3%;
text-align:left;
font-size:1.1rem;
`
export const Coursesession=styled.p`
margin-left:3%;
text-align:left;
font-size:1.1rem;
`
export const  CourseDuration =styled.p`
margin-left:3%;
text-align:left;
font-size:1.1rem;
`
export const  CourseId =styled.p`
margin-left:3%;
text-align:left;
font-size:1.1rem;
`
export const  CourseMilesTone =styled.p`
margin-left:3%;
text-align:left;
font-size:1.1rem;
`
export const  LiveSessionCount =styled.p`
margin-left:3%;
text-align:left;
font-size:1.1rem;
`
export const SubjectID=styled.p`
margin-left:3%;
text-align:left;
font-size:1.1rem;
`
export const CommonText=styled.span`
margin-left:3%;
text-align:left;
font-size:1.1rem;
font-weight:500;
color:purple;
`
export const DetailsContainer=styled.div`
grid-template-columns:30% 69%;
/* background-color:pink; */
column-gap:0px;
display:grid;
height:26rem;

/* border:2px solid red; */
`
export const DescriptionContainer=styled.div`
position:relative;
/* background-color:green; */
`
export const SubejectDetails=styled.div`
position:relative;
/* background-color:blue; */
`
