// import React, { useState } from "react";
import {
  Coursetitle,
  MainContainer,
  ImageContainer,
  Img,
  CourseDetailsContainer,
  TitleHeading,
  CourseInfo,
  CourseName,
  CourseDuration,
  CourseId,
  SubjectID,
  Coursesession,
  CourseMilesTone,
  LiveSessionCount,
  DetailsContainer,
  DescriptionContainer,
  SubejectDetails,
  CommonText,

} from "./CourseDetialsElements";
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";

const CourseDetails = () => {
  // const [data,setData]=useState([])
  const location = useLocation();
  const CourseSelector = useSelector((state) => state.courseReducer.course);
  // setData(CourseSelector)
  {
  }
  const { idSubject, imageUrl, info, name, sessionCount, subjectName,milestoneCount,liveSessionCount,duration,idCourse } =
    location.state.item;
  console.log("CourseSelector", location.state.item);
  console.log("CourseSelector", idSubject, info);
  return (
    <MainContainer>
      <ImageContainer>
        <Img src={imageUrl} />
      </ImageContainer>
      <CourseDetailsContainer>
        <Coursetitle>
          <TitleHeading>{name}</TitleHeading>
        </Coursetitle>
        
        <DetailsContainer>
        <SubejectDetails>
        <CourseName><CommonText>Subject Name:</CommonText>{subjectName}</CourseName>
        <SubjectID><CommonText>Subject Id:</CommonText>{idSubject}</SubjectID>
        <Coursesession><CommonText>Sesseion Count:</CommonText>{sessionCount}</Coursesession>
        <CourseDuration><CommonText>Duration:</CommonText>{duration}</CourseDuration>
        <CourseId><CommonText>CourseID:</CommonText>{idCourse}</CourseId>
        <CourseMilesTone><CommonText>CourseMilesTone:</CommonText>{milestoneCount}</CourseMilesTone>
        <LiveSessionCount><CommonText>LiveSessionCount:</CommonText>{liveSessionCount}</LiveSessionCount>
        </SubejectDetails>
        <DescriptionContainer>
        <CourseInfo><CommonText>Descirption:</CommonText>{info}</CourseInfo>
        </DescriptionContainer>
        </DetailsContainer>
             
      </CourseDetailsContainer>
    </MainContainer>
  );
};

export default CourseDetails;
