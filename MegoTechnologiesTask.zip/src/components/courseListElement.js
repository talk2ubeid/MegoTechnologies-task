import styled from "styled-components";

export const  CardContainer  =styled.div`
position: relative;
background-color:white;
left:10%;
width:20rem;
height:30rem;
margin:3%;
cursor: pointer;
display:inline-block;
box-shadow:2px 2px 2px 1px lightgray;
border-radius:6px;
`
export const  ImageContainer  =styled.div`
position: relative;
width:auto;
height:15rem;
/* border:2px solid red; */
`
export const  Img  =styled.img`
width:100%;
height:15rem;
border-radius:6px;
box-shadow:1px 1px 4px lightgrey;
`
export const  TitleContainer  =styled.div`
position: relative;
/* border:2px solid red; */
height:50%;

`
export const  TitleHeading  =styled.div`
position: relative;
font-size:2rem;
padding-top:5%;
text-shadow:1px 1px 1px grey;
`
export const  CourseDetails  =styled.div`
font-size:1.2rem;
padding-top:4%;
text-shadow:.5px .5px .5px grey;
overflow: hidden;
  /* text-overflow: ellipsis; */
`
export const  CourseDiscription  =styled.div`
font-size:1rem;
padding-top:4%;
text-align:left;
color:grey;
`
export const Massage=styled.span`
position: relative;
left:20%;
padding:2%;
color:#fff;
top:15%;
background-color:purple;
border-radius:4px;
box-shadow:1px 3px 2px 2px lightgrey;
`