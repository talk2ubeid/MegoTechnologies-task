import React, { useState, useEffect } from "react";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import {
  Massage,
  CardContainer,
  ImageContainer,
  Img,
  TitleContainer,
  TitleHeading,
  CourseDetails,
  CourseDiscription,
} from "./courseListElement";
import { useNavigate } from "react-router-dom";

export const Course = () => {
  const [data, setData] = useState([]);
  const [course, setCourse] = useState([]);
  const dispatch = useDispatch();
  const selectorCourse = useSelector((state) => state.courseReducer.course);
  const navigate = useNavigate();
  const getData = async () => {
    if (selectorCourse.length > 0) {
      setCourse([...selectorCourse]);
    } else {
      const response = await axios.post(
        "https://api.bricketc.com/bricketc-backend-php/get_all_courses.php"
      );
      console.log(response.data.body);
      setCourse(response.data.body);
      dispatch({
        type: "SET_COURSE",
        data: [...response.data.body],
      });
    }
  };

  useEffect(() => {
    getData();
  }, []);
  const handleChange = (element) => {
    navigate("/coursedetails", { state: { item: element } });
  };

  
  return (
    <div>
      {course.map((element, index) => (
        <CardContainer key={index} onClick={() => handleChange(element)}>
          <ImageContainer>
            <Img src={element.imageUrl} />
          </ImageContainer>
          <TitleContainer>
            <TitleHeading>{element.subjectName}</TitleHeading>
            <CourseDetails>{element.name.substring(0, 25)}</CourseDetails>
            <CourseDiscription>
              {element.info.substring(0, 25)}
              {element.info.length > 30 && "..."}
            </CourseDiscription>
            <Massage>Click Here To see Details</Massage>
          </TitleContainer>
          
        </CardContainer>
      ))}
    </div>
  );
};
